const {Sequelize} = require("sequelize");
const sequelize = new Sequelize('postgres://postgres:root@localhost:5432/postgres');

const fs = require('fs');

const models = [
  require("./todo.model")
]

db = {sequelize: sequelize, Sequelize: Sequelize}

for (const model of models) {
  model(sequelize)
}

// sequelize.sync({alter: true})
module.exports = db
