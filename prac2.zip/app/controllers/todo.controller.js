const db = require('../models/init.js')

exports.create = async (req, res) => {
  res.setHeader('content-type', 'text/plain')
  if (!req.body.title) {
    res.status(400).send('empty body')
    return
  }

  let todo = {
    title: req.body.title,
    description: req.body.description,
  }

  try {
    todo = await db.sequelize.models.Todo.create(todo)
  } catch {
    res.status(500).send("error while creating todo")
  }

  res.setHeader('location', '/todos/' + todo.id)
    .sendStatus(201)
}

exports.find = async (req, res) => {
  res.setHeader('content-type', 'text/plain')
  const id = req.params.id

  try {
    const todo = await db.sequelize.models.Todo.findOne({
      where: {
        id: parseInt(id)
      }
    })

    if (!todo) {
      res.sendStatus(404)
    } else {
      res.setHeader('content-type', 'application/json')
        .status(200)
        .send(todo)
    }
  } catch (e) {
    res.status(500).send("error while finding todo")
  }
}

exports.list = async (req, res) => {
  try {
    const todos = await db.sequelize.models.Todo.findAll()

    res.status(200)
      .send(todos)
  } catch (e) {
    res.status(500).send("error while finding todos")
  }
}

exports.delete = async (req, res) => {
  const id = req.params.id

  try {
    await db.sequelize.models.Todo.destroy({
      where: {
        id: parseInt(id)
      }
    })

    res.sendStatus(204)
  } catch (e) {
    res.status(500).send("error while deleting todo")
  }
}

exports.update = async (req, res) => {
  const id = req.params.id

  if (!req.body.title && !req.body.description) {
    res.status(400)
      .send("empty request")
    return
  }

  let todo = {
    title: req.body.title,
    description: req.body.description,
  }

  try {
    await db.sequelize.models.Todo.update(todo, {
      where: {
        id: parseInt(id),
      }
    })

    res.status(200)
      .send(todo)
  } catch (e) {
    res.status(500).send("error while updating todo")
  }
}