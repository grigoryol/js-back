const express = require('express')
const port = 3000

const app = express()
const cors = require('cors');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const todoController = require('./app/controllers/todo.controller')

const db = require('./app/models/init.js')
db.sequelize.sync().then(() => console.log('Synchronized!'))

app.get('/todos/:id', todoController.find)
app.get('/todos', todoController.list)
app.post('/todos', todoController.create)
app.delete('/todos/:id', todoController.delete)
app.put('/todos/:id', todoController.update)

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})